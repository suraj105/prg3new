package management.events;

public interface Event
{
}
