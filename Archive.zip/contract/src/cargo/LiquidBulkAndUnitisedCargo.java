package cargo;

public interface LiquidBulkAndUnitisedCargo extends LiquidBulkCargo, UnitisedCargo
{
}
