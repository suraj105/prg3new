package cargo;

public interface LiquidAndDryBulkCargo extends LiquidBulkCargo, DryBulkCargo
{
}
