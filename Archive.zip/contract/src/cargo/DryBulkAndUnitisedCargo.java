package cargo;

public interface DryBulkAndUnitisedCargo extends DryBulkCargo, UnitisedCargo
{
}
