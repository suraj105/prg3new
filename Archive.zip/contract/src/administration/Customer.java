package administration;

public interface Customer
{
    String getName();
}
